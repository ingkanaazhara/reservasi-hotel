-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 23, 2022 at 06:36 AM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 7.4.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `app_hotel`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_detail_kamar`
--

CREATE TABLE `tbl_detail_kamar` (
  `id_detail_kamar` int(11) NOT NULL,
  `id_kamar` int(11) NOT NULL,
  `id_fasilitas_kamar` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_detail_kamar`
--

INSERT INTO `tbl_detail_kamar` (`id_detail_kamar`, `id_kamar`, `id_fasilitas_kamar`) VALUES
(22, 3, 4),
(23, 3, 5),
(24, 3, 6),
(25, 3, 7),
(26, 3, 8),
(27, 6, 4),
(28, 6, 5),
(29, 6, 6),
(30, 6, 7),
(31, 6, 8),
(35, 5, 4),
(36, 5, 5),
(37, 5, 6),
(38, 5, 8),
(39, 2, 4),
(40, 2, 5),
(41, 2, 6);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_fasilitas_hotel`
--

CREATE TABLE `tbl_fasilitas_hotel` (
  `id_fasilitas_hotel` int(11) NOT NULL,
  `nama_fasilitas` varchar(20) NOT NULL,
  `deskripsi_fasilitas` varchar(50) NOT NULL,
  `foto_fasilitas` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_fasilitas_hotel`
--

INSERT INTO `tbl_fasilitas_hotel` (`id_fasilitas_hotel`, `nama_fasilitas`, `deskripsi_fasilitas`, `foto_fasilitas`) VALUES
(6, 'parkiran', 'parkiran yg luas ', 'parkir.jpg'),
(7, 'kolam renang', 'kolam renang air panas dan air dingin', 'kolam renang.jpg'),
(11, 'gym', 'tempat para tamu berolahraga', 'gym.jpg'),
(12, 'restaurant', 'restaurant yg menyediakan berbagai makanan', 'restoran.jpg'),
(13, 'mushola', 'mushola hotel', 'untitled.png');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_fasilitas_kamar`
--

CREATE TABLE `tbl_fasilitas_kamar` (
  `id_fasilitas_kamar` int(11) NOT NULL,
  `nama_fasilitas` varchar(150) NOT NULL,
  `deskripsi_fasilitas` mediumtext NOT NULL,
  `foto_fasilitas` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_fasilitas_kamar`
--

INSERT INTO `tbl_fasilitas_kamar` (`id_fasilitas_kamar`, `nama_fasilitas`, `deskripsi_fasilitas`, `foto_fasilitas`) VALUES
(4, 'kamar mandi', 'kamar mandi luas', 'kamar mandi.jpg'),
(5, 'wifi', 'wifi', 'hospot.jpg'),
(6, 'AC', 'penyegar ruangan', 'AC.jpg'),
(7, 'Kulkas mini', 'kulkas mini ', 'kulkas.jpg'),
(8, 'televisi', 'tv keren', 'tv.jpeg');

--
-- Triggers `tbl_fasilitas_kamar`
--
DELIMITER $$
CREATE TRIGGER `hapusFasilitasKamar` AFTER DELETE ON `tbl_fasilitas_kamar` FOR EACH ROW DELETE FROM tbl_detail_kamar WHERE id_fasilitas_kamar=OLD.id_fasilitas_kamar
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_kamar`
--

CREATE TABLE `tbl_kamar` (
  `id_kamar` int(11) NOT NULL,
  `harga_kamar` int(11) NOT NULL,
  `tipe_kamar` enum('standar','deluxe','single','suite') NOT NULL,
  `foto_kamar` varchar(300) NOT NULL,
  `jml_kamar` mediumtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_kamar`
--

INSERT INTO `tbl_kamar` (`id_kamar`, `harga_kamar`, `tipe_kamar`, `foto_kamar`, `jml_kamar`) VALUES
(2, 500000, 'standar', 'standar.jpg', '4'),
(3, 2000000, 'deluxe', 'deluxe.jpg', '7'),
(5, 600000, 'single', 'single room.jpg', '8'),
(6, 2000000, 'suite', 'suite.jpg', '7');

--
-- Triggers `tbl_kamar`
--
DELIMITER $$
CREATE TRIGGER `hapusDetailKamar` AFTER DELETE ON `tbl_kamar` FOR EACH ROW delete from tbl_detail_kamar where tbl_detail_kamar.id_kamar=old.id_kamar
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_reservasi`
--

CREATE TABLE `tbl_reservasi` (
  `id_reservasi` int(11) NOT NULL,
  `nama_pemesan` varchar(100) NOT NULL,
  `no_handphone` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `nama_tamu` varchar(100) NOT NULL,
  `id_kamar` int(11) NOT NULL,
  `tgl_cek_in` date NOT NULL,
  `tgl_cek_out` date NOT NULL,
  `jml_kamar_dipesan` int(11) NOT NULL,
  `status` enum('in','out') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_reservasi`
--

INSERT INTO `tbl_reservasi` (`id_reservasi`, `nama_pemesan`, `no_handphone`, `email`, `nama_tamu`, `id_kamar`, `tgl_cek_in`, `tgl_cek_out`, `jml_kamar_dipesan`, `status`) VALUES
(3, 'ingkana', '08912345678', 'ingkana@gmail.com', 'een', 2, '2022-03-31', '2022-04-01', 1, 'in'),
(4, 'lusi', '0823456789', 'lusi@gmail.com', 'hana', 2, '2022-04-02', '2022-04-04', 1, 'out'),
(5, 'sinta', '0896622222', 'sinta@gmail.com', 'santi', 3, '2022-05-21', '2022-05-23', 1, 'out'),
(6, 'lulu', '0896622222', 'lulu@gmail.com', 'lulu', 3, '2022-05-24', '2022-05-25', 1, 'out'),
(7, 'helva', '0896622222', 'helva@gmail.com', 'helva', 6, '2022-05-21', '2022-05-23', 1, 'out'),
(8, 'aesa', '2443234534', 'aesa@gmail.com', 'esa', 3, '2022-05-20', '2022-05-23', 1, 'out'),
(9, 'fira', '098776655', 'fira@gmail.com', 'fira', 3, '2022-05-23', '2022-05-25', 1, 'out');

--
-- Triggers `tbl_reservasi`
--
DELIMITER $$
CREATE TRIGGER `infoJmlKamar` AFTER UPDATE ON `tbl_reservasi` FOR EACH ROW BEGIN
   	 IF (NEW.status='in') THEN
   		 UPDATE tbl_kamar SET jml_kamar=jml_kamar-OLD.jml_kamar_dipesan
   		 WHERE tbl_kamar.id_kamar=NEW.id_kamar;
   	 ELSE
   		 UPDATE tbl_kamar SET jml_kamar=jml_kamar+OLD.jml_kamar_dipesan
   		 WHERE tbl_kamar.id_kamar=NEW.id_kamar;   	 
   	 END IF;    
    END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE `tbl_user` (
  `username` varchar(30) NOT NULL,
  `password` char(32) NOT NULL,
  `namauser` varchar(30) NOT NULL,
  `leveluser` enum('Admin','Petugas') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`username`, `password`, `namauser`, `leveluser`) VALUES
('ingkana', '202cb962ac59075b964b07152d234b70', 'ingkana', 'Admin'),
('petugas', '202cb962ac59075b964b07152d234b70', 'petugas', 'Petugas');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_detail_kamar`
--
ALTER TABLE `tbl_detail_kamar`
  ADD PRIMARY KEY (`id_detail_kamar`);

--
-- Indexes for table `tbl_fasilitas_hotel`
--
ALTER TABLE `tbl_fasilitas_hotel`
  ADD PRIMARY KEY (`id_fasilitas_hotel`);

--
-- Indexes for table `tbl_fasilitas_kamar`
--
ALTER TABLE `tbl_fasilitas_kamar`
  ADD PRIMARY KEY (`id_fasilitas_kamar`);

--
-- Indexes for table `tbl_kamar`
--
ALTER TABLE `tbl_kamar`
  ADD PRIMARY KEY (`id_kamar`);

--
-- Indexes for table `tbl_reservasi`
--
ALTER TABLE `tbl_reservasi`
  ADD PRIMARY KEY (`id_reservasi`);

--
-- Indexes for table `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_detail_kamar`
--
ALTER TABLE `tbl_detail_kamar`
  MODIFY `id_detail_kamar` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT for table `tbl_fasilitas_hotel`
--
ALTER TABLE `tbl_fasilitas_hotel`
  MODIFY `id_fasilitas_hotel` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `tbl_fasilitas_kamar`
--
ALTER TABLE `tbl_fasilitas_kamar`
  MODIFY `id_fasilitas_kamar` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `tbl_kamar`
--
ALTER TABLE `tbl_kamar`
  MODIFY `id_kamar` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tbl_reservasi`
--
ALTER TABLE `tbl_reservasi`
  MODIFY `id_reservasi` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
