<?php

namespace App\Controllers;

use App\Controllers\BaseController;

class User extends BaseController
{
    public function index() 
    {
        return view('admin/login');
    }

    public function login()
    {
       // di kelas XI $_POST['txtUser']
       //1.menampung username dan password
       $usernya    = $this->request->getPost('txtUser');
       $passwordnya   = md5($this->request->getPost('txtPass'));

       $syarat=[
           'username'=>$usernya,
           'password'=>$passwordnya
       ];

       // mencari user berdasarkan syarat diatas
       $queryUser = $this->admin->where($syarat)->find();

    //var_dump($queryUser);
        if(count($queryUser)==1){
            $dataSession=[
                'user' =>$queryUser[0]['username'],
                'nama' =>$queryUser[0]['namauser'],
                'level' =>$queryUser[0]['leveluser'],
                'sudahkahLogin'=>true
            ];
            session()->set($dataSession);
            
         return redirect()->to(site_url('/dashboard'));
       }  else {

            return redirect()->to(site_url('/login'))->with('info','<div style="color:red;font-size:10px">Gagal Login</div>');
    }
    }

    public function logout(){
        session()->destroy();
        //mengarah ke halaman login
        return redirect()->to(site_url('/login'));
    }

}
